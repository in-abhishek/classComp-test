import React from 'react'

class Render extends React.Component {
    render()  
    //state ,dom load , PROPS UPDATE
    {
        
        console.log("rednder on update");
        return (
            <div>Render</div>
        )
    }
}

export default Render