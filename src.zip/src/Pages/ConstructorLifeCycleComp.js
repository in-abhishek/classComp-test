import React from 'react'
import ConstructorLifeCycle from '../Components/ConstructorLifeCycle';

const ConstructorLifeCycleComp = () => {
  return (
    <>
    <div>ConstructorLifeCycleComp</div>
    <ConstructorLifeCycle />
    </>
  )
}

export default ConstructorLifeCycleComp