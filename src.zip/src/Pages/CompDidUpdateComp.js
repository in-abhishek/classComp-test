import React from 'react'
import ComponentDidUpdate from '../Components/ComponentDidUpdate'

const CompDidUpdateComp = () => {
  return (
    <div>
        {/* ComponentDidUpdate */}
      <ComponentDidUpdate />
    </div>
  )
}

export default CompDidUpdateComp