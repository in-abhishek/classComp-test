import React from 'react'
import ComponenentDidMount from '../Components/ComponentDidMount';

const ComponenentDidMountComp = () => {
  return (
    <div>
        <ComponenentDidMount />
    </div>
  )
}

export default ComponenentDidMountComp