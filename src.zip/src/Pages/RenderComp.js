import React from 'react'
import Render from '../Components/Render';

const RenderComp = () => {
  return (
    <div>
        <Render />
    </div>
  )
}

export default RenderComp